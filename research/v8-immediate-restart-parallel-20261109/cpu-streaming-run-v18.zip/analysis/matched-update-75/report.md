# V8 switching analysis

status: from recorded outputs

## endpoints

```json
{
 "budget": {
  "n_seeds": 3,
  "scope": "continuation_algorithm (cold-start incomplete)",
  "unit": "gpu_seconds",
  "value": 0.1474055921037992
 },
 "matched_update": 75
}
```

## primary_rebuttal

```json
{
 "loso": {
  "complete_seeds": [
   5,
   6,
   7
  ],
  "dependence_note": "folds share tuning seeds; per-seed deltas are not IID",
  "grid_best_same_seeds": {
   "label": "same-seed hindsight (optimistic)",
   "means": {
    "50": 0.7501785714285715
   },
   "tau": 50
  },
  "missing_seeds": [],
  "oracle": {
   "5": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.82375,
    "tau": 50
   },
   "6": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.7517857142857143,
    "tau": 50
   },
   "7": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.675,
    "tau": 50
   }
  },
  "per_seed": {
   "5": {
    "fold_means": {
     "50": 0.7133928571428572
    },
    "tau_hat": 50,
    "tied": [
     50
    ],
    "tuned_reward": 0.82375
   },
   "6": {
    "fold_means": {
     "50": 0.749375
    },
    "tau_hat": 50,
    "tied": [
     50
    ],
    "tuned_reward": 0.7517857142857143
   },
   "7": {
    "fold_means": {
     "50": 0.7877678571428571
    },
    "tau_hat": 50,
    "tied": [
     50
    ],
    "tuned_reward": 0.675
   }
  },
  "tau_hat_unstable": false,
  "tau_hat_values": [
   50
  ],
  "taus": [
   50
  ]
 },
 "minus_grid_best": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": null,
  "label": "minus same-seed grid best (optimistic)",
  "losses": 0,
  "mean_delta_pp": 0.16666666666666682,
  "missing_seeds": [],
  "n_training_seeds": 3,
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "5": 0.5000000000000004,
   "6": 0.0,
   "7": 0.0
  },
  "sample_sd_delta_pp": 0.28867513459481314,
  "ties": 2,
  "wins": 1
 },
 "minus_oracle": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": null,
  "label": "minus per-seed oracle",
  "losses": 0,
  "mean_delta_pp": 0.16666666666666682,
  "missing_seeds": [],
  "n_training_seeds": 3,
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "5": 0.5000000000000004,
   "6": 0.0,
   "7": 0.0
  },
  "sample_sd_delta_pp": 0.28867513459481314,
  "ties": 2,
  "wins": 1
 },
 "primary_contrast": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": "withheld as primary: crossfit folds share tuning seeds (not IID)",
  "label": "srgc_current - LOSO tuned fixed",
  "losses": 0,
  "mean_delta_pp": 0.16666666666666682,
  "missing_seeds": [],
  "n_training_seeds": 3,
  "naive_paired_t": {
   "caveat": "paired t treating LOSO folds as independent; the same seeds tune and evaluate (rebuttal plan v2 6.2), so this interval is optimistic",
   "ci_high": 0.8838333333333341,
   "ci_low": -0.5505000000000004,
   "confidence": 0.95,
   "df": 2,
   "p_two_sided": null
  },
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "5": 0.5000000000000004,
   "6": 0.0,
   "7": 0.0
  },
  "sample_sd_delta_pp": 0.28867513459481314,
  "ties": 2,
  "wins": 1
 }
}
```

## primary_rebuttal_budget

```json
{
 "loso": {
  "complete_seeds": [
   5,
   6,
   7
  ],
  "dependence_note": "folds share tuning seeds; per-seed deltas are not IID",
  "grid_best_same_seeds": {
   "label": "same-seed hindsight (optimistic)",
   "means": {
    "50": 0.7620833333333333
   },
   "tau": 50
  },
  "missing_seeds": [],
  "oracle": {
   "5": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.82375,
    "tau": 50
   },
   "6": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.8125,
    "tau": 50
   },
   "7": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.65,
    "tau": 50
   }
  },
  "per_seed": {
   "5": {
    "fold_means": {
     "50": 0.73125
    },
    "tau_hat": 50,
    "tied": [
     50
    ],
    "tuned_reward": 0.82375
   },
   "6": {
    "fold_means": {
     "50": 0.736875
    },
    "tau_hat": 50,
    "tied": [
     50
    ],
    "tuned_reward": 0.8125
   },
   "7": {
    "fold_means": {
     "50": 0.818125
    },
    "tau_hat": 50,
    "tied": [
     50
    ],
    "tuned_reward": 0.65
   }
  },
  "tau_hat_unstable": false,
  "tau_hat_values": [
   50
  ],
  "taus": [
   50
  ]
 },
 "minus_grid_best": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": null,
  "label": "minus same-seed grid best (optimistic)",
  "losses": 1,
  "mean_delta_pp": -1.0937499999999987,
  "missing_seeds": [
   5
  ],
  "n_training_seeds": 2,
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "6": -7.499999999999996,
   "7": 5.312499999999998
  },
  "sample_sd_delta_pp": 9.059805633952635,
  "ties": 0,
  "wins": 1
 },
 "minus_oracle": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": null,
  "label": "minus per-seed oracle",
  "losses": 1,
  "mean_delta_pp": -1.0937499999999987,
  "missing_seeds": [
   5
  ],
  "n_training_seeds": 2,
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "6": -7.499999999999996,
   "7": 5.312499999999998
  },
  "sample_sd_delta_pp": 9.059805633952635,
  "ties": 0,
  "wins": 1
 },
 "primary_contrast": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": "withheld as primary: crossfit folds share tuning seeds (not IID)",
  "label": "srgc_current - LOSO tuned fixed",
  "losses": 1,
  "mean_delta_pp": -1.0937499999999987,
  "missing_seeds": [
   5
  ],
  "n_training_seeds": 2,
  "naive_paired_t": {
   "caveat": "paired t treating LOSO folds as independent; the same seeds tune and evaluate (rebuttal plan v2 6.2), so this interval is optimistic",
   "ci_high": 80.30406249999994,
   "ci_low": -82.49156249999994,
   "confidence": 0.95,
   "df": 1,
   "p_two_sided": null
  },
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "6": -7.499999999999996,
   "7": 5.312499999999998
  },
  "sample_sd_delta_pp": 9.059805633952635,
  "ties": 0,
  "wins": 1
 }
}
```

## primary_rebuttal_extended

```json
{
 "loso": {
  "complete_seeds": [
   5,
   6,
   7
  ],
  "dependence_note": "folds share tuning seeds; per-seed deltas are not IID",
  "grid_best_same_seeds": {
   "label": "same-seed hindsight (optimistic)",
   "means": {
    "25": 0.8202083333333333,
    "50": 0.7501785714285715
   },
   "tau": 25
  },
  "missing_seeds": [],
  "oracle": {
   "5": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.83875,
    "tau": 25
   },
   "6": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.825,
    "tau": 25
   },
   "7": {
    "label": "per-seed hindsight oracle (reference only)",
    "reward": 0.796875,
    "tau": 25
   }
  },
  "per_seed": {
   "5": {
    "fold_means": {
     "25": 0.8109375,
     "50": 0.7133928571428572
    },
    "tau_hat": 25,
    "tied": [
     25
    ],
    "tuned_reward": 0.83875
   },
   "6": {
    "fold_means": {
     "25": 0.8178125,
     "50": 0.749375
    },
    "tau_hat": 25,
    "tied": [
     25
    ],
    "tuned_reward": 0.825
   },
   "7": {
    "fold_means": {
     "25": 0.8318749999999999,
     "50": 0.7877678571428571
    },
    "tau_hat": 25,
    "tied": [
     25
    ],
    "tuned_reward": 0.796875
   }
  },
  "tau_hat_unstable": false,
  "tau_hat_values": [
   25
  ],
  "taus": [
   25,
   50
  ]
 },
 "minus_grid_best": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": null,
  "label": "minus same-seed grid best (optimistic)",
  "losses": 3,
  "mean_delta_pp": -6.836309523809522,
  "missing_seeds": [],
  "n_training_seeds": 3,
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "5": -1.0000000000000009,
   "6": -7.321428571428568,
   "7": -12.187499999999996
  },
  "sample_sd_delta_pp": 5.609504829329598,
  "ties": 0,
  "wins": 0
 },
 "minus_oracle": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": null,
  "label": "minus per-seed oracle",
  "losses": 3,
  "mean_delta_pp": -6.836309523809522,
  "missing_seeds": [],
  "n_training_seeds": 3,
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "5": -1.0000000000000009,
   "6": -7.321428571428568,
   "7": -12.187499999999996
  },
  "sample_sd_delta_pp": 5.609504829329598,
  "ties": 0,
  "wins": 0
 },
 "primary_contrast": {
  "ci_high": null,
  "ci_low": null,
  "interval_method": "withheld as primary: crossfit folds share tuning seeds (not IID)",
  "label": "srgc_current - LOSO tuned fixed",
  "losses": 3,
  "mean_delta_pp": -6.836309523809522,
  "missing_seeds": [],
  "n_training_seeds": 3,
  "naive_paired_t": {
   "caveat": "paired t treating LOSO folds as independent; the same seeds tune and evaluate (rebuttal plan v2 6.2), so this interval is optimistic",
   "ci_high": 7.099597653466162,
   "ci_low": -20.772216701085206,
   "confidence": 0.95,
   "df": 2,
   "p_two_sided": null
  },
  "p_two_sided": null,
  "per_seed_delta_pp": {
   "5": -1.0000000000000009,
   "6": -7.321428571428568,
   "7": -12.187499999999996
  },
  "sample_sd_delta_pp": 5.609504829329598,
  "ties": 0,
  "wins": 0
 }
}
```

## secondary

- {'label': 'srgc_current - on_continued', 'n_training_seeds': 3, 'mean_delta_pp': -4.226190476190472, 'sample_sd_delta_pp': 4.382585746238083, 'per_seed_delta_pp': {5: 0.0, 6: -3.9285714285714257, 7: -8.749999999999991}, 'missing_seeds': [], 'wins': 0, 'ties': 1, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -15.114015696821333, 'ci_high': 6.661634744440389, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - fixed_sr_t050', 'n_training_seeds': 3, 'mean_delta_pp': 0.16666666666666682, 'sample_sd_delta_pp': 0.28867513459481314, 'per_seed_delta_pp': {5: 0.5000000000000004, 6: 0.0, 7: 0.0}, 'missing_seeds': [], 'wins': 1, 'ties': 2, 'losses': 0, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -0.5505000000000004, 'ci_high': 0.8838333333333341, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - srgc_two_negative', 'n_training_seeds': 3, 'mean_delta_pp': 0.0, 'sample_sd_delta_pp': 0.0, 'per_seed_delta_pp': {5: 0.0, 6: 0.0, 7: 0.0}, 'missing_seeds': [], 'wins': 0, 'ties': 3, 'losses': 0, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': 0.0, 'ci_high': 0.0, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_two_negative - srgc_one_negative', 'n_training_seeds': 3, 'mean_delta_pp': -6.336309523809521, 'sample_sd_delta_pp': 6.4008599981554335, 'per_seed_delta_pp': {5: 0.5000000000000004, 6: -7.321428571428568, 7: -12.187499999999996}, 'missing_seeds': [], 'wins': 1, 'ties': 0, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -22.238210583353094, 'ci_high': 9.565591535734054, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - plateau_sr_eps0005', 'n_training_seeds': 3, 'mean_delta_pp': -4.226190476190472, 'sample_sd_delta_pp': 4.382585746238083, 'per_seed_delta_pp': {5: 0.0, 6: -3.9285714285714257, 7: -8.749999999999991}, 'missing_seeds': [], 'wins': 0, 'ties': 1, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -15.114015696821333, 'ci_high': 6.661634744440389, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - plateau_sr_eps0000', 'n_training_seeds': 3, 'mean_delta_pp': -4.226190476190472, 'sample_sd_delta_pp': 4.382585746238083, 'per_seed_delta_pp': {5: 0.0, 6: -3.9285714285714257, 7: -8.749999999999991}, 'missing_seeds': [], 'wins': 0, 'ties': 1, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -15.114015696821333, 'ci_high': 6.661634744440389, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - plateau_sr_eps0010', 'n_training_seeds': 3, 'mean_delta_pp': -4.226190476190472, 'sample_sd_delta_pp': 4.382585746238083, 'per_seed_delta_pp': {5: 0.0, 6: -3.9285714285714257, 7: -8.749999999999991}, 'missing_seeds': [], 'wins': 0, 'ties': 1, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -15.114015696821333, 'ci_high': 6.661634744440389, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - srgc_three_negative', 'n_training_seeds': 3, 'mean_delta_pp': -4.226190476190472, 'sample_sd_delta_pp': 4.382585746238083, 'per_seed_delta_pp': {5: 0.0, 6: -3.9285714285714257, 7: -8.749999999999991}, 'missing_seeds': [], 'wins': 0, 'ties': 1, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -15.114015696821333, 'ci_high': 6.661634744440389, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - srgc_current_c50', 'n_training_seeds': 3, 'mean_delta_pp': -4.226190476190472, 'sample_sd_delta_pp': 4.382585746238083, 'per_seed_delta_pp': {5: 0.0, 6: -3.9285714285714257, 7: -8.749999999999991}, 'missing_seeds': [], 'wins': 0, 'ties': 1, 'losses': 2, 'interval_method': 'paired_seed_t (df=2, normal-error assumption, n=3)', 'ci_low': -15.114015696821333, 'ci_high': 6.661634744440389, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - srgc_uniform_destination', 'n_training_seeds': 2, 'mean_delta_pp': -3.482142857142856, 'sample_sd_delta_pp': 5.682108063106181, 'per_seed_delta_pp': {6: 0.5357142857142838, 7: -7.499999999999996}, 'missing_seeds': [5], 'wins': 1, 'ties': 0, 'losses': 1, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': -54.53303571428567, 'ci_high': 47.56874999999996, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - sampled_time_sr.d0', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['sampled_time_sr.d0'], 'exploratory': True}
- {'label': 'E3 same-parent SR - Uniform at tau_s (050)', 'n_training_seeds': 2, 'mean_delta_pp': -3.482142857142856, 'sample_sd_delta_pp': 5.682108063106181, 'per_seed_delta_pp': {6: 0.5357142857142838, 7: -7.499999999999996}, 'missing_seeds': [5], 'wins': 1, 'ties': 0, 'losses': 1, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': -54.53303571428567, 'ci_high': 47.56874999999996, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'reward_fraction'}

## secondary_budget

- {'label': 'srgc_current - on_continued', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['on_continued'], 'exploratory': True}
- {'label': 'srgc_current - fixed_sr_t050', 'n_training_seeds': 2, 'mean_delta_pp': -1.0937499999999987, 'sample_sd_delta_pp': 9.059805633952635, 'per_seed_delta_pp': {6: -7.499999999999996, 7: 5.312499999999998}, 'missing_seeds': [5], 'wins': 1, 'ties': 0, 'losses': 1, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': -82.49156249999994, 'ci_high': 80.30406249999994, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'budget_reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - srgc_two_negative', 'n_training_seeds': 2, 'mean_delta_pp': 0.0, 'sample_sd_delta_pp': 0.0, 'per_seed_delta_pp': {6: 0.0, 7: 0.0}, 'missing_seeds': [5], 'wins': 0, 'ties': 2, 'losses': 0, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': 0.0, 'ci_high': 0.0, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'budget_reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_two_negative - srgc_one_negative', 'n_training_seeds': 2, 'mean_delta_pp': -9.062499999999996, 'sample_sd_delta_pp': 0.4419417382415985, 'per_seed_delta_pp': {6: -8.749999999999991, 7: -9.375}, 'missing_seeds': [5], 'wins': 0, 'ties': 0, 'losses': 2, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': -13.033125000000052, 'ci_high': -5.09187499999994, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'budget_reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - plateau_sr_eps0005', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['plateau_sr_eps0005'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0000', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['plateau_sr_eps0000'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0010', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['plateau_sr_eps0010'], 'exploratory': True}
- {'label': 'srgc_current - srgc_three_negative', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_three_negative'], 'exploratory': True}
- {'label': 'srgc_current - srgc_current_c50', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current_c50'], 'exploratory': True}
- {'label': 'srgc_current - srgc_uniform_destination', 'n_training_seeds': 2, 'mean_delta_pp': 0.0, 'sample_sd_delta_pp': 0.0, 'per_seed_delta_pp': {6: 0.0, 7: 0.0}, 'missing_seeds': [5], 'wins': 0, 'ties': 2, 'losses': 0, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': 0.0, 'ci_high': 0.0, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'budget_reward_fraction', 'tau_mismatch_seeds': []}
- {'label': 'srgc_current - sampled_time_sr.d0', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['sampled_time_sr.d0'], 'exploratory': True}
- {'label': 'E3 same-parent SR - Uniform at tau_s (050)', 'n_training_seeds': 2, 'mean_delta_pp': -5.937499999999996, 'sample_sd_delta_pp': 11.932426932522986, 'per_seed_delta_pp': {6: 2.500000000000002, 7: -14.374999999999993}, 'missing_seeds': [5], 'wins': 1, 'ties': 0, 'losses': 1, 'interval_method': 'paired_seed_t (df=1, normal-error assumption, n=2)', 'ci_low': -113.14437499999995, 'ci_high': 101.26937499999995, 'p_two_sided': None, 'confidence': 0.95, 'exploratory': True, 'key': 'budget_reward_fraction'}

## status_counts

```json
{
 "fixed_sr_t025": {
  "triggered": 3
 },
 "fixed_sr_t050": {
  "triggered": 3
 },
 "fixed_uniform_t050": {
  "triggered": 2
 },
 "on_continued": {
  "not_triggered": 3
 },
 "plateau_sr_eps0000": {
  "not_triggered": 3
 },
 "plateau_sr_eps0005": {
  "not_triggered": 3
 },
 "plateau_sr_eps0010": {
  "not_triggered": 3
 },
 "srgc_current": {
  "not_triggered": 1,
  "triggered": 2
 },
 "srgc_current_c50": {
  "not_triggered": 3
 },
 "srgc_one_negative": {
  "triggered": 3
 },
 "srgc_one_negative_c50": {
  "triggered": 3
 },
 "srgc_three_negative": {
  "not_triggered": 3
 },
 "srgc_three_negative_c50": {
  "not_triggered": 3
 },
 "srgc_two_negative": {
  "not_triggered": 1,
  "triggered": 2
 },
 "srgc_two_negative_c50": {
  "not_triggered": 3
 },
 "srgc_uniform_destination": {
  "triggered": 2
 }
}
```

## budget_status_counts

```json
{
 "fixed_sr_t025": {
  "selected": 3
 },
 "fixed_sr_t050": {
  "selected": 3
 },
 "fixed_uniform_t050": {
  "selected": 2
 },
 "on_continued": {
  "capped_at_horizon": 3
 },
 "plateau_sr_eps0000": {
  "capped_at_horizon": 3
 },
 "plateau_sr_eps0005": {
  "capped_at_horizon": 3
 },
 "plateau_sr_eps0010": {
  "capped_at_horizon": 3
 },
 "srgc_current": {
  "capped_at_horizon": 1,
  "selected": 2
 },
 "srgc_current_c50": {
  "capped_at_horizon": 3
 },
 "srgc_one_negative": {
  "selected": 3
 },
 "srgc_one_negative_c50": {
  "selected": 3
 },
 "srgc_three_negative": {
  "capped_at_horizon": 3
 },
 "srgc_three_negative_c50": {
  "capped_at_horizon": 3
 },
 "srgc_two_negative": {
  "capped_at_horizon": 1,
  "selected": 2
 },
 "srgc_two_negative_c50": {
  "capped_at_horizon": 3
 },
 "srgc_uniform_destination": {
  "selected": 2
 }
}
```

## e3

- {'seed': 5, 'status': 'not_triggered'}
- {'seed': 6, 'tau_s': 50, 'sr': 0.7517857142857143, 'uniform': 0.7464285714285714, 'delta_pp': 0.5357142857142838, 'status': 'paired'}
- {'seed': 7, 'tau_s': 50, 'sr': 0.675, 'uniform': 0.75, 'delta_pp': -7.499999999999996, 'status': 'paired'}

## e4

- {'seed': 5, 'policy_id': 'srgc_one_negative', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.82375, 'continuation_gpu_seconds': 0.15054617449641228}
- {'seed': 5, 'policy_id': 'srgc_two_negative', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.82875, 'continuation_gpu_seconds': 0.13926787115633488}
- {'seed': 5, 'policy_id': 'srgc_current', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.82875, 'continuation_gpu_seconds': 0.13926787115633488}
- {'seed': 5, 'policy_id': 'srgc_three_negative', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.82875, 'continuation_gpu_seconds': 0.13926787115633488}
- {'seed': 5, 'policy_id': 'srgc_one_negative_c50', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.82375, 'continuation_gpu_seconds': 0.1415178868919611}
- {'seed': 5, 'policy_id': 'srgc_two_negative_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.82875, 'continuation_gpu_seconds': 0.1302395835518837}
- {'seed': 5, 'policy_id': 'srgc_current_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.82875, 'continuation_gpu_seconds': 0.1302395835518837}
- {'seed': 5, 'policy_id': 'srgc_three_negative_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.82875, 'continuation_gpu_seconds': 0.1302395835518837}
- {'seed': 6, 'policy_id': 'srgc_one_negative', 'status': 'triggered', 'switch_update': 25, 'observed_through': 25, 'checks_used': 1, 'reward_fraction': 0.825, 'continuation_gpu_seconds': 0.13710527028888464}
- {'seed': 6, 'policy_id': 'srgc_two_negative', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.7517857142857143, 'continuation_gpu_seconds': 0.15172860212624073}
- {'seed': 6, 'policy_id': 'srgc_current', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.7517857142857143, 'continuation_gpu_seconds': 0.15172860212624073}
- {'seed': 6, 'policy_id': 'srgc_three_negative', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.7910714285714285, 'continuation_gpu_seconds': 0.14113187696784735}
- {'seed': 6, 'policy_id': 'srgc_one_negative_c50', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7517857142857143, 'continuation_gpu_seconds': 0.14348898641765118}
- {'seed': 6, 'policy_id': 'srgc_two_negative_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7910714285714285, 'continuation_gpu_seconds': 0.1328922612592578}
- {'seed': 6, 'policy_id': 'srgc_current_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7910714285714285, 'continuation_gpu_seconds': 0.1328922612592578}
- {'seed': 6, 'policy_id': 'srgc_three_negative_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7910714285714285, 'continuation_gpu_seconds': 0.1328922612592578}
- {'seed': 7, 'policy_id': 'srgc_one_negative', 'status': 'triggered', 'switch_update': 25, 'observed_through': 25, 'checks_used': 1, 'reward_fraction': 0.796875, 'continuation_gpu_seconds': 0.13709402829408646}
- {'seed': 7, 'policy_id': 'srgc_two_negative', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.675, 'continuation_gpu_seconds': 0.15122030302882195}
- {'seed': 7, 'policy_id': 'srgc_current', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.675, 'continuation_gpu_seconds': 0.15122030302882195}
- {'seed': 7, 'policy_id': 'srgc_three_negative', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 2, 'reward_fraction': 0.7625, 'continuation_gpu_seconds': 0.14185102935880423}
- {'seed': 7, 'policy_id': 'srgc_one_negative_c50', 'status': 'triggered', 'switch_update': 50, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.675, 'continuation_gpu_seconds': 0.14278441946953535}
- {'seed': 7, 'policy_id': 'srgc_two_negative_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7625, 'continuation_gpu_seconds': 0.13341514579951763}
- {'seed': 7, 'policy_id': 'srgc_current_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7625, 'continuation_gpu_seconds': 0.13341514579951763}
- {'seed': 7, 'policy_id': 'srgc_three_negative_c50', 'status': 'not_triggered', 'switch_update': None, 'observed_through': 50, 'checks_used': 1, 'reward_fraction': 0.7625, 'continuation_gpu_seconds': 0.13341514579951763}

## primary_test

```json
{
 "ci_high": null,
 "ci_low": null,
 "interval_method": null,
 "label": "srgc_current - fixed_sr_tuned (matched update)",
 "losses": 0,
 "mean_delta_pp": null,
 "missing_seeds": [],
 "n_training_seeds": 0,
 "p_two_sided": null,
 "per_seed_delta_pp": {},
 "sample_sd_delta_pp": null,
 "ties": 0,
 "wins": 0
}
```

## primary_test_budget

```json
{
 "ci_high": null,
 "ci_low": null,
 "interval_method": null,
 "label": "srgc_current - fixed_sr_tuned (frozen budget)",
 "losses": 0,
 "mean_delta_pp": null,
 "missing_seeds": [],
 "n_training_seeds": 0,
 "p_two_sided": null,
 "per_seed_delta_pp": {},
 "sample_sd_delta_pp": null,
 "ties": 0,
 "wins": 0
}
```

## secondary_test

- {'label': 'srgc_current - on_continued', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'on_continued'], 'exploratory': True}
- {'label': 'srgc_current - fixed_sr_t050', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'fixed_sr_t050'], 'exploratory': True}
- {'label': 'srgc_current - srgc_two_negative', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'srgc_two_negative'], 'exploratory': True}
- {'label': 'srgc_two_negative - srgc_one_negative', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_two_negative', 'srgc_one_negative'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0005', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'plateau_sr_eps0005'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0000', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'plateau_sr_eps0000'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0010', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'plateau_sr_eps0010'], 'exploratory': True}
- {'label': 'srgc_current - srgc_three_negative', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'srgc_three_negative'], 'exploratory': True}
- {'label': 'srgc_current - srgc_current_c50', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'srgc_current_c50'], 'exploratory': True}
- {'label': 'srgc_current - srgc_uniform_destination', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'srgc_uniform_destination'], 'exploratory': True}
- {'label': 'srgc_current - sampled_time_sr.d0', 'status': 'missing_policy', 'key': 'reward_fraction', 'missing': ['srgc_current', 'sampled_time_sr.d0'], 'exploratory': True}

## secondary_test_budget

- {'label': 'srgc_current - on_continued', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'on_continued'], 'exploratory': True}
- {'label': 'srgc_current - fixed_sr_t050', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'fixed_sr_t050'], 'exploratory': True}
- {'label': 'srgc_current - srgc_two_negative', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'srgc_two_negative'], 'exploratory': True}
- {'label': 'srgc_two_negative - srgc_one_negative', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_two_negative', 'srgc_one_negative'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0005', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'plateau_sr_eps0005'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0000', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'plateau_sr_eps0000'], 'exploratory': True}
- {'label': 'srgc_current - plateau_sr_eps0010', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'plateau_sr_eps0010'], 'exploratory': True}
- {'label': 'srgc_current - srgc_three_negative', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'srgc_three_negative'], 'exploratory': True}
- {'label': 'srgc_current - srgc_current_c50', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'srgc_current_c50'], 'exploratory': True}
- {'label': 'srgc_current - srgc_uniform_destination', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'srgc_uniform_destination'], 'exploratory': True}
- {'label': 'srgc_current - sampled_time_sr.d0', 'status': 'missing_policy', 'key': 'budget_reward_fraction', 'missing': ['srgc_current', 'sampled_time_sr.d0'], 'exploratory': True}

## physical_expenditure

```json
{
 "complete": true,
 "gpu_seconds": 1.68464634,
 "killed_phase_starts": 0,
 "known_lower_bound_gpu_seconds": 1.68464634,
 "missing_events": 0,
 "scope": "every recorded attempt, branch and evaluation"
}
```

## pareto

```json
{
 "status": "skipped_no_matplotlib"
}
```
