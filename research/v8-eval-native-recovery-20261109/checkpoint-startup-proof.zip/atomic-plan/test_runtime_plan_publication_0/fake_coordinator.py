
import hashlib,json,os,sys,time,uuid
from pathlib import Path
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()
def atomic(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp');tmp.write_text(canonical(value)+'\n');os.replace(tmp,path)
class Runtime:
    def __init__(self,runner,root,cohort,python,gpus):
        self.root=Path(root).resolve()/cohort;self.cohort=cohort;self.gpus=gpus
        self.binding=dict(schema=1,cohort=cohort,root=str(self.root),runner_sha256={'fixture':'cpu'},
                          coordinator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
        self.n=int(os.environ.get('FAKE_TASKS','3'));self.sleep=float(os.environ.get('FAKE_SLEEP','0.2'))
    def verify_node(self):pass
    def barrier(self,action,fd,stop,device_fds):self.root.mkdir(parents=True,exist_ok=True)
    def tasks(self):
        return [dict(kind='train',run_id=f'{self.cohort}.s5.m{i}',method_id='on_monitored' if i==0 else f'bank_sr_t{i:03d}',
                     training_seed=5,cohort_id=self.cohort,role='rebuttal_bank',config_hash='c',horizon=275,parent={}) for i in range(self.n)]
    def plan(self,phase):
        if phase=='train':return self.tasks(),True
        if phase=='extension':return [],True
        return [dict(kind='evaluate',run_id=t['run_id'],training_seed=5,completed_update=275,snapshot_path='x',
                     snapshot_sha256=digest(['s',t['run_id']]),evaluation_spec_hash=digest('e'),task_id='eval.'+t['run_id'],
                     split='final',responses=4) for t in self.tasks()],True
    def ready(self,task):return True
    def native_busy(self,task):return False
    def done(self,task):return (self.root/'done'/(task.get('task_id') or task['run_id'])).exists()
    def execute(self,task,matrix,fd,stop,device_fds,attempt):
        node=os.environ.get('FAKE_NODE','?');name=task.get('task_id') or task['run_id']
        (self.root/'starts').mkdir(parents=True,exist_ok=True)
        (self.root/'starts'/(name+'.'+node+'.'+attempt['id'][:6])).write_text(attempt['worker'])
        if os.environ.get('FAKE_FAULT_NODE')==node:
            if os.environ.get('FAKE_FAULT')=='actor_exit':os._exit(9)  # e.g. the actor is OOM-killed
            raise RuntimeError('NCCL admission failed on GPUs 0,1,2,3: simulated node-local fabric fault')
        end=time.monotonic()+self.sleep
        while time.monotonic()<end:
            if stop.is_set():return 75
            time.sleep(.01)
        (self.root/'done').mkdir(exist_ok=True);(self.root/'done'/name).write_text(node)
        return 0
